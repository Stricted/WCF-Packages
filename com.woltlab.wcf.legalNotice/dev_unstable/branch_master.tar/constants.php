<?php
/**
 * Defines constants for autocompletion in IDEs. This file is not meant to be actively used anywhere!
 *
 * @author	Matthias Schmidt
 * @copyright	2001-2016 WoltLab GmbH
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package	WoltLabSuite\Core
 */

// option constants
define('LEGAL_NOTICE_ADDRESS', '');
define('LEGAL_NOTICE_EMAIL_ADDRESS', '');
define('LEGAL_NOTICE_PHONE', '');
define('LEGAL_NOTICE_FAX', '');
define('LEGAL_NOTICE_REPRESENTATIVE', '');
define('LEGAL_NOTICE_REGISTER', '');
define('LEGAL_NOTICE_VAT_ID', '');
define('LEGAL_NOTICE_ADDITIONAL_TEXT', '');
define('LEGAL_NOTICE_ADDITIONAL_TEXT_ENABLE_HTML', 0);
