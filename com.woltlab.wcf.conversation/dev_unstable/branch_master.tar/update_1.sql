ALTER TABLE wcf1_conversation_message DROP COLUMN enableSmilies;
