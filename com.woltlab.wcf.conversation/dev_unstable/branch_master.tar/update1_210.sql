ALTER TABLE wcf1_conversation_message ADD lastEditTime INT(10) NOT NULL DEFAULT 0;
