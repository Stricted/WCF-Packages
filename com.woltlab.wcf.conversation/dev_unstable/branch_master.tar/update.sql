ALTER TABLE wcf1_conversation_message DROP COLUMN enableSmilies;
ALTER TABLE wcf1_conversation_message DROP COLUMN enableBBCodes;
ALTER TABLE wcf1_conversation_message DROP COLUMN showSignature;