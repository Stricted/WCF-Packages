ALTER TABLE wcf1_conversation_message ADD hasEmbeddedObjects TINYINT(1) NOT NULL DEFAULT 0;
