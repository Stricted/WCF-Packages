ALTER TABLE wcf1_conversation_message ADD editCount MEDIUMINT(7) NOT NULL DEFAULT 0;
