# Changelog

## 3.0

### 3.0.0 Alpha 1 (XXXX-YY-ZZ)

* Only search active conversation when using search bar in a conversation.
* Filter option for conversation participants on conversation list page.
* Increased number of items in conversation drop down to 10.
* Overhauled conversation drop down.
* Changed label of wcf.conversation.lastVisitTime

#### Documentation

* `@property-read` tags for database table columns of classes extending `wcf\data\DatabaseObject`.
