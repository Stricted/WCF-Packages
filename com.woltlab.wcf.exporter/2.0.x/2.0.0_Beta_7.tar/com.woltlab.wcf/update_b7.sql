/* 8d8368e */
DROP TABLE wcf1_import_mapping;